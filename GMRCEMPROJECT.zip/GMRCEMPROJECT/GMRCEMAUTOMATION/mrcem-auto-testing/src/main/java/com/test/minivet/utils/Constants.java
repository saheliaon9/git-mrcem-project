package com.test.minivet.utils;

public class Constants {

    private Constants() {}
       public static final long TIMINGS_IMPLICIT_TIMEOUT = 20;
    public static final long TIMINGS_EXPLICIT_TIMEOUT = 30;

//    public static final String email_Err_msg = "Email is already registered";




}